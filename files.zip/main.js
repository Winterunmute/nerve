const { app, BrowserWindow, Tray, Menu, nativeImage, ipcMain, dialog } = require('electron')
const path = require('path')
const fs = require('fs')

let tray = null
let win = null

function createTrayIcon() {
  // Green circle as base64 PNG — no file needed
  const { nativeImage } = require('electron')
  const icon = nativeImage.createFromDataURL(
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAbElEQVR42u3XsQ0AIAhEUTZgXjdxHwfT1hjRGAOeyRXU/1UKoqrycuRLQC6pWuMGWEVvMC7hE4h7fIcIia8QYXELERqfIbAAEfERQcCTeI8ggAAC+BBhAfgdQ2xEEDshxFYMcRdAXEYwt6HXNPuilaCsY3LMAAAAAElFTkSuQmCC'
  )
  return icon
}

function createWindow() {
  win = new BrowserWindow({
    width: 680,
    height: 700,
    show: false,
    frame: false,
    resizable: true,
    backgroundColor: '#0f0f0f',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
    icon: path.join(__dirname, 'icon.png')
  })

  win.loadFile('index.html')

  win.on('close', (e) => {
    e.preventDefault()
    win.hide()
  })
}

app.whenReady().then(() => {
  createWindow()

  const trayIcon = createTrayIcon()
  tray = new Tray(trayIcon)
  tray.setToolTip('Haro — Zero System')

  const contextMenu = Menu.buildFromTemplate([
    { label: 'Open Haro', click: () => { win.show(); win.focus() } },
    { type: 'separator' },
    { label: 'Quit', click: () => { app.exit(0) } }
  ])

  tray.setContextMenu(contextMenu)
  tray.on('click', () => {
    if (win.isVisible()) {
      win.hide()
    } else {
      win.show()
      win.focus()
    }
  })
})

app.on('window-all-closed', (e) => {
  e.preventDefault()
})

// IPC: save files to sync folder
ipcMain.handle('save-project', async (event, { projectName, syncPath, plan, tasks }) => {
  try {
    const projectDir = path.join(syncPath, projectName)
    
    if (!fs.existsSync(projectDir)) {
      fs.mkdirSync(projectDir, { recursive: true })
    }

    fs.writeFileSync(path.join(projectDir, 'plan.md'), plan, 'utf8')
    
    const tasksContent = tasks.map(t => `- [ ] ${t}`).join('\n') + '\n'
    fs.writeFileSync(path.join(projectDir, 'tasks.md'), tasksContent, 'utf8')

    return { success: true, path: projectDir }
  } catch (err) {
    return { success: false, error: err.message }
  }
})

// IPC: browse for sync folder
ipcMain.handle('browse-folder', async () => {
  const result = await dialog.showOpenDialog(win, {
    properties: ['openDirectory'],
    title: 'Select Sync Folder'
  })
  if (!result.canceled && result.filePaths.length > 0) {
    return result.filePaths[0]
  }
  return null
})

// IPC: close/minimize
ipcMain.on('close-window', () => win.hide())
ipcMain.on('minimize-window', () => win.minimize())

// IPC: list existing projects in sync folder
ipcMain.handle('list-projects', async (event, syncPath) => {
  try {
    if (!require('fs').existsSync(syncPath)) return []
    return require('fs').readdirSync(syncPath, { withFileTypes: true })
      .filter(d => d.isDirectory() && !d.name.startsWith('.'))
      .map(d => d.name)
      .sort()
  } catch (err) { return [] }
})

// IPC: load existing project files
ipcMain.handle('load-project', async (event, { syncPath, projectName }) => {
  try {
    const projectDir = path.join(syncPath, projectName)
    const planPath  = path.join(projectDir, 'plan.md')
    const tasksPath = path.join(projectDir, 'tasks.md')
    const plan  = fs.existsSync(planPath)  ? fs.readFileSync(planPath,  'utf8') : ''
    const tasks = fs.existsSync(tasksPath) ? fs.readFileSync(tasksPath, 'utf8') : ''
    return { success: true, plan, tasks }
  } catch (err) { return { success: false, error: err.message } }
})
